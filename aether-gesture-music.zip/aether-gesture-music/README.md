# Aether — Hand Gesture Music

Play a synth and drum beat with your hands. Runs entirely in the browser using your webcam, [MediaPipe Hands](https://developers.google.com/mediapipe) and the Web Audio API. No install or build step.

## Gestures
| Hand | Gesture | Effect |
|------|---------|--------|
| Melody (right side of screen) | Move left/right | Pick a note (A minor pentatonic) |
| Melody | Move up/down | Filter brightness |
| Melody | Pinch thumb + index | Play note (release to fade) |
| Rhythm (left side of screen) | Open palm / fist | Start / stop beat |
| Rhythm | Raise / lower hand | Tempo 60-160 BPM |

If the camera or model can't load, use **Mouse mode** (move = note/tone, hold click = play).

## Run locally
Camera access needs `localhost` or HTTPS:

```bash
python3 -m http.server 8000
# open http://localhost:8000
```

## Deploy on GitHub Pages
1. Push these files to a GitHub repo.
2. Repo **Settings → Pages → Deploy from a branch → main / root**.
3. Open `https://<your-username>.github.io/<repo-name>/`.

## Roadmap
Selectable scales and instruments, chord gestures, loop recording, MIDI output.

## License
MIT
